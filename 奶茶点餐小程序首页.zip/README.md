
  # 奶茶点餐小程序首页

  This is a code bundle for 奶茶点餐小程序首页. The original project is available at https://www.figma.com/design/GIgPEcrFtu20FAF7Y37qOC/%E5%A5%B6%E8%8C%B6%E7%82%B9%E9%A4%90%E5%B0%8F%E7%A8%8B%E5%BA%8F%E9%A6%96%E9%A1%B5.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  