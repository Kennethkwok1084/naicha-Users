import { useState, useEffect } from "react";
import { Home, ShoppingCart, ClipboardList, User, Store, ShoppingBag, Bike, Coffee, MapPin, Phone, Clock } from "lucide-react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import { Card } from "./components/ui/card";
import { Badge } from "./components/ui/badge";
import { Carousel, CarouselContent, CarouselItem, type CarouselApi } from "./components/ui/carousel";
import Autoplay from "embla-carousel-autoplay@8.5.1";

export default function App() {
  const [activeTab, setActiveTab] = useState("home");
  const [bannerApi, setBannerApi] = useState<CarouselApi>();
  const [adApi, setAdApi] = useState<CarouselApi>();
  const [currentBanner, setCurrentBanner] = useState(0);
  const [currentAd, setCurrentAd] = useState(0);

  // 轮播图数据
  const banners = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1670468642364-6cacadfb7bb0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidWJibGUlMjB0ZWElMjBkcmlua3xlbnwxfHx8fDE3NjE0ODU4MTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      alt: "奶茶优惠",
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1707560664096-12857c4ddb91?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxrJTIwdGVhJTIwYmV2ZXJhZ2V8ZW58MXx8fHwxNzYxNTY1NjIzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      alt: "新品推荐",
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1735964519674-440909118206?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWElMjBzaG9wJTIwaW50ZXJpb3J8ZW58MXx8fHwxNzYxNTQ1OTIxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      alt: "店铺活动",
    },
  ];

  // 广告数据
  const ads = [
    { id: 1, title: "新用户专享", subtitle: "首单立减10元", color: "bg-gradient-to-r from-orange-400 to-pink-500" },
    { id: 2, title: "会员日福利", subtitle: "全场8.8折", color: "bg-gradient-to-r from-purple-400 to-blue-500" },
    { id: 3, title: "推荐好友", subtitle: "各得5元红包", color: "bg-gradient-to-r from-green-400 to-teal-500" },
  ];

  // 集杯数据
  const stamps = Array.from({ length: 10 }, (_, i) => i < 6);

  // 监听轮播图变化
  useEffect(() => {
    if (!bannerApi) return;
    
    const onSelect = () => {
      setCurrentBanner(bannerApi.selectedScrollSnap());
    };
    
    bannerApi.on("select", onSelect);
    return () => {
      bannerApi.off("select", onSelect);
    };
  }, [bannerApi]);

  // 监听广告轮播变化
  useEffect(() => {
    if (!adApi) return;
    
    const onSelect = () => {
      setCurrentAd(adApi.selectedScrollSnap());
    };
    
    adApi.on("select", onSelect);
    return () => {
      adApi.off("select", onSelect);
    };
  }, [adApi]);

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* 顶部轮播图 */}
      <div className="bg-white relative">
        <Carousel
          setApi={setBannerApi}
          opts={{ loop: true }}
          plugins={[
            Autoplay({
              delay: 3000,
            }),
          ]}
        >
          <CarouselContent>
            {banners.map((banner) => (
              <CarouselItem key={banner.id}>
                <div className="relative h-48">
                  <ImageWithFallback
                    src={banner.image}
                    alt={banner.alt}
                    className="w-full h-full object-cover"
                  />
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
        </Carousel>
        {/* 轮播指示器 */}
        <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-2">
          {banners.map((_, index) => (
            <div
              key={index}
              className={`h-1.5 rounded-full transition-all ${
                index === currentBanner ? "w-6 bg-white" : "w-1.5 bg-white/50"
              }`}
            />
          ))}
        </div>
      </div>

      {/* 功能区 */}
      <div className="bg-white mt-2 px-4 py-6">
        <div className="grid grid-cols-3 gap-4">
          <button className="flex flex-col items-center gap-2 p-4 rounded-xl bg-orange-50 hover:bg-orange-100 transition-colors">
            <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center">
              <Store className="w-6 h-6 text-white" />
            </div>
            <span className="text-gray-800">堂食点单</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 rounded-xl bg-blue-50 hover:bg-blue-100 transition-colors">
            <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
              <ShoppingBag className="w-6 h-6 text-white" />
            </div>
            <span className="text-gray-800">打包带走</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 rounded-xl bg-green-50 hover:bg-green-100 transition-colors">
            <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
              <Bike className="w-6 h-6 text-white" />
            </div>
            <span className="text-gray-800">外卖配送</span>
          </button>
        </div>
      </div>

      {/* 广告轮播 */}
      <div className="mt-2 px-4 relative">
        <Carousel
          setApi={setAdApi}
          opts={{ loop: true }}
          plugins={[
            Autoplay({
              delay: 4000,
            }),
          ]}
        >
          <CarouselContent>
            {ads.map((ad) => (
              <CarouselItem key={ad.id}>
                <div className={`${ad.color} rounded-xl p-6 text-white`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xl">{ad.title}</div>
                      <div className="text-sm opacity-90 mt-1">{ad.subtitle}</div>
                    </div>
                    <div className="bg-white/20 px-4 py-2 rounded-full text-sm">
                      去使用
                    </div>
                  </div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
        </Carousel>
        {/* 轮播指示器 */}
        <div className="absolute -bottom-3 left-0 right-0 flex justify-center gap-2">
          {ads.map((_, index) => (
            <div
              key={index}
              className={`h-1 rounded-full transition-all ${
                index === currentAd ? "w-4 bg-orange-500" : "w-1 bg-gray-300"
              }`}
            />
          ))}
        </div>
      </div>

      {/* 集杯卡 */}
      <Card className="mt-6 mx-4 p-6 bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Coffee className="w-5 h-5 text-amber-600" />
            <span className="text-gray-800">我的集杯卡</span>
          </div>
          <Badge className="bg-amber-500">6/10杯</Badge>
        </div>
        <div className="grid grid-cols-5 gap-3">
          {stamps.map((filled, index) => (
            <div
              key={index}
              className={`aspect-square rounded-lg flex items-center justify-center ${
                filled ? "bg-amber-500" : "bg-white border-2 border-amber-200"
              }`}
            >
              <Coffee className={`w-6 h-6 ${filled ? "text-white" : "text-amber-200"}`} />
            </div>
          ))}
        </div>
        <div className="mt-4 text-sm text-amber-700 text-center">
          再来4杯即可兑换免费饮品一杯
        </div>
      </Card>

      {/* 店铺情况 */}
      <Card className="mt-2 mx-4 p-6 mb-4">
        <div className="flex items-center gap-2 mb-4">
          <Store className="w-5 h-5 text-gray-700" />
          <span className="text-gray-800">店铺信息</span>
        </div>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-gray-500 mt-0.5" />
            <div>
              <div className="text-gray-800">人民广场店</div>
              <div className="text-sm text-gray-500 mt-0.5">上海市黄浦区南京西路123号</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Phone className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">021-12345678</span>
          </div>
          <div className="flex items-start gap-3">
            <Clock className="w-5 h-5 text-gray-500 mt-0.5" />
            <div>
              <div className="text-gray-800">营业时间</div>
              <div className="text-sm text-gray-500 mt-0.5">周一至周日 09:00 - 22:00</div>
            </div>
          </div>
        </div>
        <button className="w-full mt-4 bg-gray-100 hover:bg-gray-200 text-gray-800 py-3 rounded-lg transition-colors">
          查看更多门店
        </button>
      </Card>

      {/* 底部导航栏 */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
        <div className="grid grid-cols-4">
          <button
            onClick={() => setActiveTab("home")}
            className={`flex flex-col items-center gap-1 py-3 ${
              activeTab === "home" ? "text-orange-500" : "text-gray-500"
            }`}
          >
            <Home className="w-6 h-6" />
            <span className="text-xs">首页</span>
          </button>
          <button
            onClick={() => setActiveTab("order")}
            className={`flex flex-col items-center gap-1 py-3 ${
              activeTab === "order" ? "text-orange-500" : "text-gray-500"
            }`}
          >
            <ShoppingCart className="w-6 h-6" />
            <span className="text-xs">点单</span>
          </button>
          <button
            onClick={() => setActiveTab("orders")}
            className={`flex flex-col items-center gap-1 py-3 ${
              activeTab === "orders" ? "text-orange-500" : "text-gray-500"
            }`}
          >
            <ClipboardList className="w-6 h-6" />
            <span className="text-xs">订单</span>
          </button>
          <button
            onClick={() => setActiveTab("profile")}
            className={`flex flex-col items-center gap-1 py-3 ${
              activeTab === "profile" ? "text-orange-500" : "text-gray-500"
            }`}
          >
            <User className="w-6 h-6" />
            <span className="text-xs">我的</span>
          </button>
        </div>
      </div>
    </div>
  );
}
